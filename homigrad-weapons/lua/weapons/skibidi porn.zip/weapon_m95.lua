SWEP.Base = "homigrad_base"
SWEP.PrintName = "Barret M95"
SWEP.Category = "Оружие: Снайперские Винтовки"
SWEP.Spawnable = true

SWEP.WorldModel = "models/weapons/w_snip_m95.mdl"
SWEP.WorldModelReal = "models/weapons/v_snip_m95.mdl"
SWEP.ViewModel = "models/weapons/v_snip_m95.mdl"

SWEP.HoldType = "ar2"

SWEP.Primary.ReloadTime = 3.5
SWEP.Primary.Automatic = true
SWEP.Primary.ClipSize = 5
SWEP.Primary.DefaultClip = 5
SWEP.Primary.Damage = 60
SWEP.Primary.Force = 1
SWEP.Primary.Ammo = "7.62x51 mm"
SWEP.Primary.Wait = 1
SWEP.Sound = "weapon/sniperrifle/sniperrifle_fire_player_01.wav"
SWEP.RecoilForce = 7

SWEP.WorldPos = Vector(-2,1,1)
SWEP.WorldAng = Angle(1,0,0)
SWEP.AttPos = Vector(32,3.5,-3.45)
SWEP.AttAng = Angle(0,0,0)
SWEP.HolsterAng = Angle(0,-10,0)
SWEP.HolsterPos = Vector(-22,1,6)
SWEP.HolsterBone = "ValveBiped.Bip01_Spine4"

SWEP.IconPos = Vector(200,-18.5,-2.5)
SWEP.IconAng = Angle(0,90,0)

SWEP.TwoHands = true

SWEP.Rarity = 5

SWEP.BoltBone = nil
SWEP.BoltVec = nil

SWEP.ZoomPos = Vector(2,-3.1,2)
SWEP.ZoomAng = Angle(-0.8,-0.05,0)

SWEP.Animations = {
	["idle"] = {
        Source = "idle",
    },
	["draw"] = {
        Source = "draw",
        MinProgress = 0.5,
        Time = 1.5
    },
    ["fire"] = {
        Source = "fire",
        MinProgress = 0.5,
        Time = 1
    },
    ["reload"] = {
        Source = "reload",
        MinProgress = 0.5,
        Time = 3.5
    },
}

SWEP.Reload1 = false
SWEP.Reload2 = false
SWEP.Reload3 = false
SWEP.Reload4 = false