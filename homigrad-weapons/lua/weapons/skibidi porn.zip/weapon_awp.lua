SWEP.Base = "homigrad_base"
SWEP.PrintName = "AWP"
SWEP.Category = "Оружие: Снайперские Винтовки"
SWEP.Spawnable = true

SWEP.WorldModel = "models/weapons/arccw_go/v_snip_awp.mdl"
SWEP.WorldModelReal = "models/weapons/arccw_go/v_snip_awp.mdl"
SWEP.ViewModel = "models/weapons/arccw_go/v_snip_awp.mdl"

SWEP.Bodygroups = {[1] = 0,[2] = 0,[3] = 0,[4] = 0,[5] = 0,[6] = 0,[7] = 0}

SWEP.HoldType = "ar2"

SWEP.holdtypes = {
    ["ar2"] = {[1] = 0.27,[2] = 0.7,[3] = 1.45,[4] = 1.47},
}

SWEP.Primary.ReloadTime = 2.5
SWEP.Primary.Automatic = false
SWEP.Primary.ClipSize = 10
SWEP.Primary.DefaultClip = 10
SWEP.Primary.Damage = 35
SWEP.Primary.Force = 7
SWEP.Primary.Ammo = "5.56x45 mm"
SWEP.Primary.Wait = 1
SWEP.Sound = "arccw_go/awp/awp_01.wav"
SWEP.SuppressedSound = "zcitysnd/sound/weapons/m4a1/m4a1_suppressed_fp.wav"
SWEP.RecoilForce = 5

SWEP.WorldPos = Vector(-9,-3,1)
SWEP.WorldAng = Angle(1,0,0)
SWEP.AttPos = Vector(27,5,-4)
SWEP.AttAng = Angle(0,0,0)
SWEP.HolsterAng = Angle(0,-10,0)
SWEP.HolsterPos = Vector(-28,-1,10)
SWEP.HolsterBone = "ValveBiped.Bip01_Spine4"

SWEP.IconPos = Vector(145,-25,-3)
SWEP.IconAng = Angle(0,90,0)

SWEP.TwoHands = true

SWEP.Rarity = 5

SWEP.BoltBone = nil
SWEP.BoltVec = nil

SWEP.ZoomPos = Vector(12,-4.95,-1.6)
SWEP.ZoomAng = Angle(0,0,0)

SWEP.AttBone = "m16_parent"

SWEP.MountType = "picatinny"

SWEP.AvaibleAtt = {
    ["sight"] = true,
    ["barrel"] = true,
    ["grip"] = false
}

SWEP.AttachmentPos = {
    ['sight'] = Vector(2,0,1.55),
    ['barrel'] = Vector(15.5,0,0.35),
    ['grip'] = Vector(-9,0,-1)
}
SWEP.AttachmentAng = {
    ['sight'] = Angle(-90,0,-90),
    ['barrel'] = Angle(-90,0,-90),
    ['grip'] = Angle(-90,0,90)
}

SWEP.Animations = {
	["idle"] = {
        Source = "idle",
    },
	["draw"] = {
        Source = "draw",
        MinProgress = 0.5,
        Time = 0.5
    },
    ["fire"] = {
        Source = "cycle",
        MinProgress = 0.5,
        Time = 1
    },
    ["reload"] = {
        Source = "reload",
        MinProgress = 0.5,
        Time = 2.8
    },
    ["reload_empty"] = {
        Source = "reload_empty",
        MinProgress = 0.5,
        Time = 2.8
    }
}

SWEP.Reload1 = "arccw_go/awp/awp_clipin.wav"
-- Дальше я ебал что либо добавлять потому что хуево работает
