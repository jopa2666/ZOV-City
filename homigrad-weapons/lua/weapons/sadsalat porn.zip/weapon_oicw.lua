SWEP.Base = "homigrad_base"
SWEP.PrintName = "OICW"
SWEP.Category = "ХЛ2 Оружие: Винтовки"
SWEP.Spawnable = true
-- кэт петушара

SWEP.WorldModel = "models/weapons/oicw/w_oicw.mdl"
SWEP.WorldModelReal = "models/weapons/oicw/c_oicw.mdl"
SWEP.ViewModel = "models/weapons/oicw/c_oicw.mdl"

SWEP.HoldType = "ar2"

SWEP.holdtypes = {
    ["ar2"] = {[1] = 0.35,[2] = 1,[3] = 1.3,[4] = 0},
}

SWEP.Primary.ReloadTime = 3
SWEP.Primary.Automatic = true
SWEP.Primary.ClipSize = 35
SWEP.Primary.DefaultClip = 35
SWEP.Primary.Damage = 47
SWEP.Primary.Force = 1.3
SWEP.Primary.Ammo = "7.62x51 mm"
SWEP.Primary.Wait = 0.09
SWEP.Sound = {"weapon/oicw/oicw_fire_player_04.wav","weapon/oicw/oicw_fire_player_02.wav","weapon/oicw/oicw_fire_player_12.wav"}
SWEP.RecoilForce = 1.1
SWEP.Empty3 = false

SWEP.WorldPos = Vector(-9,-3,2.5)
SWEP.WorldAng = Angle(1,-2,-1)
SWEP.AttPos = Vector(37,6,-4.8)
SWEP.AttAng = Angle(0,0,0)
SWEP.HolsterAng = Angle(5,0,0)
SWEP.HolsterPos = Vector(-26,-2,12)
SWEP.HolsterBone = "ValveBiped.Bip01_Spine4"

SWEP.BoltBone = "OICWMainbolt"
SWEP.BoltVec = Vector(1.5,0,0)

SWEP.ZoomPos = Vector(9,-6,0.6)
SWEP.ZoomAng = Angle(-0.5,0,0)

SWEP.Slot = 2
SWEP.SlotPos = 0

SWEP.Rarity = 4

SWEP.TwoHands = true

SWEP.IconPos = Vector(115,-25.5,-4)
SWEP.IconAng = Angle(0,90,0)

SWEP.Animations = {
	["idle"] = {
        Source = "idle",
    },
	["draw"] = {
        Source = "draw",
        MinProgress = 0.5,
        Time = 1
    },
    ["reload"] = {
        Source = "reloadsecondary",
        MinProgress = 0.5,
        Time = 3
    },
}