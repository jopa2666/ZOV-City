SWEP.Base = "homigrad_base"
SWEP.PrintName = "P90"
SWEP.Category = "Оружие: ПП"
SWEP.Spawnable = true
-- кэт петушара

SWEP.WorldModel = "models/weapons/arccw_go/v_smg_p90.mdl"
SWEP.ViewModel = "models/weapons/arccw_go/v_smg_p90.mdl"

SWEP.HoldType = "smg"

SWEP.holdtypes = {
    ["smg"] = {[1] = 0.35,[2] = 1,[3] = 1.3,[4] = 0},
}

SWEP.Primary.ReloadTime = 3
SWEP.Primary.Automatic = true
SWEP.Primary.ClipSize = 50
SWEP.Primary.DefaultClip = 50
SWEP.Primary.Damage = 35
SWEP.Primary.Force = 1
SWEP.Primary.Ammo = "5.7×28mm"
SWEP.Primary.Wait = 0.08
SWEP.Sound = "arccw_go/p90/p90_02.wav"
SWEP.RecoilForce = 0.4
SWEP.Empty3 = false

SWEP.WorldPos = Vector(-5,-1.5,0)
SWEP.WorldAng = Angle(1,-2,-1)
SWEP.AttPos = Vector(37,6,-4.8)
SWEP.AttAng = Angle(0,0,0)
SWEP.HolsterAng = Angle(-125,15,0)
SWEP.HolsterPos = Vector(-13,-15,5.5)
SWEP.HolsterBone = "ValveBiped.Bip01_Spine2"

SWEP.BoltBone = "v_weapon.p90_ChargeHandle"
SWEP.BoltVec = Vector(0,0,-2)

SWEP.ZoomPos = Vector(9,-5.5,0.6)
SWEP.ZoomAng = Angle(-0.5,0,0)

SWEP.Slot = 2
SWEP.SlotPos = 0

SWEP.Rarity = 4

SWEP.TwoHands = true

SWEP.IconPos = Vector(80,-15,-6)
SWEP.IconAng = Angle(0,90,0)

SWEP.Animations = {
	["idle"] = {
        Source = "idle",
    },
	["draw"] = {
        Source = "draw",
        MinProgress = 0.5,
        Time = 0.5
    },
    ["reload"] = {
        Source = "reload",
        MinProgress = 0.5,
        Time = 3
    },
    ["reload_empty"] = {
        Source = "reload_empty",
        MinProgress = 0.5,
        Time = 3
    },
}

SWEP.Reload1 = "arccw_go/p90/p90_clipout.wav"
SWEP.Reload2 = "arccw_go/p90/p90_cliprelease.wav"
SWEP.Reload3 = false
